

public class CircularSuffixArray {
	private int N;
	private int[] index;
	public CircularSuffixArray(String s)  {
		// circular suffix array of s
		if(s==null) throw new NullPointerException();
		N=s.length();
		index= new int[N];
		for(int i=0;i<N;i++){
			index[i]=i;	
		}
		//三向字符串快速排序
		sort(s, 0, N-1, 0);
	}
	private void sort(String s, int lo, int hi, int d){
		if(lo>=hi) return;
		int val=charAt(s, lo, d);
		int lt=lo, t=lo, ht=hi;
		while(t<=ht){
			if(charAt(s, t, d)==val) t++;
			else if(charAt(s, t, d)> val) {
				//交换index, t, ht
				{int swap = index[t]; index[t]= index[ht]; index[ht]=swap;}
				ht--;
			}else{
				//交换index, t, lt
				{int swap = index[t]; index[t]= index[lt]; index[lt]=swap;}
				t++;
				lt++;
			}
		}
		sort(s, lo, lt-1, d);
		if(val>0) sort(s, lt, t-1, d+1);//确保结尾情况
		sort(s, t, hi, d);
	}
	private int charAt(String s, int t, int d){
		//当前排在第t个字符串
		int i=index[t];
		if(d>N-1) return -1;
		if(i+d<N) return s.charAt(i+d);
		else return s.charAt(i+d-N);
	}
	
    public int length() {
    	// length of s
    	return N;
    }
    public int index(int i) {
    	// returns index of ith sorted suffix
    	if(i<0||i>N-1) throw new IndexOutOfBoundsException();
    	return index[i];
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="ABRACADABRA!";
		CircularSuffixArray suffix= new CircularSuffixArray(s);
		for(int i=0;i<suffix.length();i++){
			System.out.println(suffix.index(i));
		}
	}

}
